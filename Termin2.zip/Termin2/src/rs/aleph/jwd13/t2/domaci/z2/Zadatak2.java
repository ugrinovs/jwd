package rs.aleph.jwd13.t2.domaci.z2;

public class Zadatak2 {
	public static void ispisiPonedeljak(int i)
	{
		// Podaci za ponedeljak
				double PonedeljakOdSati[][] = {
						{},
						{7, 9, 17, 17},
						{9, 15}
				};
				double PonedeljakOdMinuta[][] = {
						{},
						{00, 45, 30, 30},
						{45, 15}
				};
				double PonedeljakDoSati[][] = {
						{},
						{8, 11, 19, 20},
						{10, 17}
				};
				double PonedeljakDoMinuta[][] = {
						{},
						{30, 15, 00, 00},
						{15, 45}
				};
				String PonedeljakPredavac[][] = {
						{},
						{"Zeljko Vuckovic", "Zeljko Vuckovic", "Sinisa Nikolic", "Aleksandar Kaplar"},
						{"Sinisa Nikolic", "Sinisa Nikolic"}
				};
				String PonedeljakPredmeti[][] = {
					{},
					{"Internet Mreze", "Internet Mreze", "Internet Mreze", "Web Programiranje"},
					{"Sistemi bazirani na znanju", "Sistemi bazirani na znanju"}
				};
				String PonedeljakKabinet[][] = {
						{},
						{"L6", "MI2", "L6", "PC6"},
						{"PC5", "PC5"}
				};
				
		for(int k = 0; k < PonedeljakOdSati[i].length; k++){
			System.out.printf("%3.0f:%2.0f %3.0f:%2.0f %-17s %-30s %s\n", PonedeljakOdSati[i][k], PonedeljakOdMinuta[i][k], PonedeljakDoSati[i][k], PonedeljakDoMinuta[i][k], PonedeljakPredavac[i][k], PonedeljakPredmeti[i][k], PonedeljakKabinet[i][k]);
			
		}
		
		//Uporedi Predavace
		String temp[][] = new String[3][6];
		for(int j = 0; j < PonedeljakPredavac.length; j++){
			for(int k = 0; k < (PonedeljakPredavac[j].length-1); k++){
					for(int l = k+1; l < PonedeljakPredavac[j].length; l++){
						if(PonedeljakPredavac[j][k] == PonedeljakPredavac[j][l] && k != l){
							temp[j][k] = PonedeljakPredavac[j][l];
							System.out.println(j+ ", "+ k + ". "+temp[j][k]);
					}
					
				}
					
			}
		}
		for(int j = 0; j < PonedeljakOdSati.length; j++){
			for(int k = 0; k < (PonedeljakOdSati[j].length-1);k++){
				for(int l = k+1; l < PonedeljakOdSati[j].length;l++){
					double preklapanje = 0;
					double proveriminute = 0;
					double nulaJe60 = 60;
					if(PonedeljakPredavac[j][l] == PonedeljakPredavac[j][k]){
						/*if(PonedeljakOdSati[j][l] > PonedeljakDoSati[j][k])
							preklapanje = PonedeljakOdSati[j][l] - PonedeljakDoSati[j][k];
						else
							preklapanje = PonedeljakDoSati[j][k] - PonedeljakOdSati[j][l];
						if(preklapanje <= 1){ 
							if(preklapanje == 1 && PonedeljakDoMinuta[j][k] >= 45 && PonedeljakOdMinuta[j][l] <= 15){
								if(PonedeljakOdMinuta[j][l] == 0)
									proveriminute = nulaJe60 - PonedeljakDoMinuta[j][k];
								else if(PonedeljakDoMinuta[j][k] == 0)
									proveriminute = nulaJe60 - PonedeljakOdMinuta[j][l];
								else
									proveriminute = (60 - PonedeljakDoMinuta[j][k]) + PonedeljakOdMinuta[j][l];
								if(proveriminute <= 15){
								System.out.println("Imamo preklapanje");
								System.out.println("Satnica je: " + PonedeljakDoSati[j][k] + " i " + PonedeljakOdSati[j][l] + "Predavac 1 je:" + PonedeljakPredavac[j][k] + "Predavac 2 je :" + PonedeljakPredavac[j][l]);
								}
							}
						}*/
						if(Math.abs(PonedeljakOdSati[j][l] - PonedeljakDoSati[j][k]) <= 1 && Math.abs(PonedeljakOdSati[j][l] - PonedeljakDoSati[j][k]) >= 0){
							if(PonedeljakOdSati[j][l] >= PonedeljakDoSati[j][k]){
								preklapanje = PonedeljakOdSati[j][l] - PonedeljakDoSati[j][k];
							}
							else
								preklapanje = PonedeljakDoSati[j][k] - PonedeljakOdSati[j][l];
							System.out.println("Imamo prekllapppppaannnjjjjjjeeeee UIF!"+ k + " " + l + PonedeljakPredavac[j][k]);
								
						}
						else if(Math.abs(PonedeljakOdSati[j][k] - PonedeljakDoSati[j][l]) <= 1 && Math.abs(PonedeljakOdSati[j][l] - PonedeljakDoSati[j+1][k]) >= 0){
							if(PonedeljakOdSati[j][k] >= PonedeljakDoSati[j][l]){
								preklapanje = PonedeljakOdSati[j][k] - PonedeljakDoSati[j][l];
							}
							else
								preklapanje = PonedeljakDoSati[j][l] - PonedeljakOdSati[j][k];
							System.out.println("Imamo prekllapppppaannnjjjjjjeeeee UELSEIF!" + PonedeljakPredavac[j][k]);
						}
					}
					else if(j < (PonedeljakPredavac.length-1) && k < PonedeljakPredavac[j+1].length && PonedeljakPredavac[j+1][k] == PonedeljakPredavac[j][l]){
						/*if(PonedeljakOdSati[j][l] >= PonedeljakDoSati[j+1][k])
							preklapanje = PonedeljakOdSati[j][l] - PonedeljakDoSati[j+1][k];
						else if(PonedeljakDoSati[j+1][k] < PonedeljakOdSati[j][l])
							preklapanje = PonedeljakDoSati[j+1][k] - PonedeljakOdSati[j][l];
						else if(PonedeljakDoSati[j][l] >= PonedeljakOdSati[j+1][k])
							preklapanje = PonedeljakDoSati[j][l] - PonedeljakOdSati[j+1][k];
						else
							preklapanje = PonedeljakOdSati[j+1][k] - PonedeljakDoSati[j][l];
						if(preklapanje <= 1)
						{ 
							if(PonedeljakDoMinuta[j+1][k] >= PonedeljakOdMinuta[j][l])
								proveriminute = PonedeljakDoMinuta[j+1][k] - PonedeljakOdMinuta[j][l];
							else 
								proveriminute = PonedeljakOdMinuta[j][l] - PonedeljakDoMinuta[j+1][k];
							if(proveriminute <= 15){
							System.out.println("Imamo preklapanje");
							System.out.println(PonedeljakPredavac[j][l]+ " ne moze da stigne na sledece predavanje jer mu pauza traje samo: " +proveriminute + " minuta.");
							}
						}*/
						
						if(Math.abs(PonedeljakOdSati[j][l] - PonedeljakDoSati[j+1][k]) <= 1 && Math.abs(PonedeljakOdSati[j][l] - PonedeljakDoSati[j+1][k]) >= 0){
							System.out.println("Preklopilo se gde je sinisa ODSATI gornji sa DOSATI DONJI");
						}
						else if(Math.abs(PonedeljakOdSati[j+1][k] - PonedeljakDoSati[j][l]) <= 1 && Math.abs(PonedeljakOdSati[j+1][k] - PonedeljakDoSati[j][l]) >= 0){
							System.out.println("Preklopilo se gde je sinisa DOSATI gornji sa ODSATI DONJI");
						}
					}
				}
			}
		}
	}
	public static void ispisiUtorak(int i){
		// Podaci za utorak
				double UtorakOdSati[][] = {
						{},
						{10, 9},
						{14, 16}
				};
				double UtorakOdMinuta[][] = {
						{},
						{30, 45},
						{15, 10}
				};
				double UtorakDoSati[][] = {
						{},
						{12, 11},
						{16, 17}
				};
				double UtorakDoMinuta[][] = {
						{},
						{00, 15},
						{00, 30}
				};
				String UtorakPredavac[][] = {
						{},
						{"Zeljko Vuckovic", "Zeljko Vuckovic"},
						{"Segedinac Milan", "Segedinac Milan"}
				};
				String UtorakPredmeti[][] = {
						{},
						{"Internet Mreze", "Internet Mreze"},
						{"XML i Web Servisi", "Web Programiranje"}
					};
				String UtorakKabinet[][] = {
						{},
						{"MI2", "MI2"},
						{"PCA", "PC3"}
				};
				
				for(int k = 0; k < UtorakOdSati[i].length; k++){
					System.out.printf("%3.0f:%2.0f %3.0f:%2.0f %-17s %-30s %s\n", UtorakOdSati[i][k], UtorakOdMinuta[i][k], UtorakDoSati[i][k], UtorakDoMinuta[i][k], UtorakPredavac[i][k], UtorakPredmeti[i][k], UtorakKabinet[i][k]);
				}
				
				//Uporedi Predavace
				String temp[][] = new String[3][6];
				for(int j = 0; j < UtorakPredavac.length; j++){
					for(int k = 0; k < (UtorakPredavac[j].length-1); k++){
							for(int l = k+1; l < UtorakPredavac[j].length; l++){
								if(UtorakPredavac[j][k] == UtorakPredavac[j][l] && k != l){
									temp[j][k] = UtorakPredavac[j][l];
									System.out.println(j+ ", "+ k + ". "+temp[j][k]);
							}
							
						}
							
					}
				}
				for(int j = 0; j < UtorakOdSati.length; j++){
					for(int k = 0; k < (UtorakOdSati[j].length-1);k++){
						for(int l = k+1; l < UtorakOdSati[j].length;l++){
							double preklapanje = 0;
							double proveriminute = 0;
							double nulaJe60 = 60;
							if(UtorakPredavac[j][l] == UtorakPredavac[j][k]){
								/*if(UtorakOdSati[j][l] > UtorakDoSati[j][k])
									preklapanje = UtorakOdSati[j][l] - UtorakDoSati[j][k];
								else
									preklapanje = UtorakDoSati[j][k] - UtorakOdSati[j][l];
								if(preklapanje <= 1){ 
									if(preklapanje == 1 && UtorakDoMinuta[j][k] >= 45 && UtorakOdMinuta[j][l] <= 15){
										if(UtorakOdMinuta[j][l] == 0)
											proveriminute = nulaJe60 - UtorakDoMinuta[j][k];
										else if(UtorakDoMinuta[j][k] == 0)
											proveriminute = nulaJe60 - UtorakOdMinuta[j][l];
										else
											proveriminute = (60 - UtorakDoMinuta[j][k]) + UtorakOdMinuta[j][l];
										if(proveriminute <= 15){
										System.out.println("Imamo preklapanje");
										System.out.println("Satnica je: " + UtorakDoSati[j][k] + " i " + UtorakOdSati[j][l] + "Predavac 1 je:" + UtorakPredavac[j][k] + "Predavac 2 je :" + UtorakPredavac[j][l]);
										}
									}
								}*/
								if(Math.abs(UtorakOdSati[j][l] - UtorakDoSati[j][k]) <= 1 || Math.abs(UtorakOdSati[j][l] - UtorakDoSati[j][k]) >= 0){
									System.out.println("Od Sati drugog se poklapa sa Do sati prvog. Predavac: " + UtorakPredavac[j][k]);
								}
								else if(Math.abs(UtorakOdSati[j][k] - UtorakDoSati[j][l]) <= 1 || Math.abs(UtorakOdSati[j][l] - UtorakDoSati[j][k]) >= 0){
									System.out.println("Do Sati drugog se poklapa sa Od sati prvog. Predavac: " + UtorakPredavac[j][k]);
								}
							}
							else if(j < (UtorakPredavac.length-1) && k < UtorakPredavac[j+1].length && UtorakPredavac[j+1][k] == UtorakPredavac[j][l]){
								/*if(UtorakOdSati[j][l] >= UtorakDoSati[j+1][k])
									preklapanje = UtorakOdSati[j][l] - UtorakDoSati[j+1][k];
								else if(UtorakDoSati[j+1][k] < UtorakOdSati[j][l])
									preklapanje = UtorakDoSati[j+1][k] - UtorakOdSati[j][l];
								else if(UtorakDoSati[j][l] >= UtorakOdSati[j+1][k])
									preklapanje = UtorakDoSati[j][l] - UtorakOdSati[j+1][k];
								else
									preklapanje = UtorakOdSati[j+1][k] - UtorakDoSati[j][l];
								if(preklapanje <= 1)
								{ 
									if(UtorakDoMinuta[j+1][k] >= UtorakOdMinuta[j][l])
										proveriminute = UtorakDoMinuta[j+1][k] - UtorakOdMinuta[j][l];
									else 
										proveriminute = UtorakOdMinuta[j][l] - UtorakDoMinuta[j+1][k];
									if(proveriminute <= 15){
									System.out.println("Imamo preklapanje");
									System.out.println(UtorakPredavac[j][l]+ " ne moze da stigne na sledece predavanje jer mu pauza traje samo: " +proveriminute + " minuta.");
									}
								}*/
								if(Math.abs(UtorakOdSati[j][l] - UtorakDoSati[j+1][k]) <= 1 || Math.abs(UtorakOdSati[j][l] - UtorakDoSati[j+1][k]) >= 0){
									System.out.println("Preklapanje u 1.nesto OdSati i 2.nesto DoSati" );
								}
								else if(Math.abs(UtorakOdSati[j+1][k] - UtorakDoSati[j][l]) <= 1 || Math.abs(UtorakOdSati[j][l] - UtorakDoSati[j+1][k]) >= 0){
									System.out.println("Preklapanje u 2.nesto OdSati i 1.nesto DoSati" );
								}
							}
						}
					}
				}
	}
	public static void ispisiSredu(int i){
		// Podaci za sredu
				double SredaOdSati[][] = {
						{12},
						{7, 10, 10, 11},
						{14}
				};
				double SredaOdMinuta[][] = {
						{30},
						{00, 30, 30, 30},
						{00}
				};
				double SredaDoSati[][] = {
						{16},
						{8, 12, 12, 13},
						{15}
				};
				double SredaDoMinuta[][] = {
						{00},
						{30, 00, 00, 00},
						{30}
				};
				String SredaPredavac[][] = {
						{"Sinisa Nikolic"},
						{"Sinisa Nikolic", "Zeljko Vuckovic", "Sinisa Nikolic", "Zeljko Vuckovic"},
						{"Zeljko Vuckovic"}
				};
				String SredaPredmeti[][] = {
						{"Objektno Programiranje"},
						{"Internet Mreze", "Internet Mreze", "Internet Mreze", "Internet Mreze"},
						{"XML i Web Servisi"}
					};
				String SredaKabinet[][] = {
						{"L6"},
						{"L3", "MI2", "L3", "MI2"},
						{"L6"}
				};
				
				for(int k = 0; k < SredaOdSati[i].length; k++){
					System.out.printf("%3.0f:%2.0f %3.0f:%2.0f %-17s %-30s %s\n", SredaOdSati[i][k], SredaOdMinuta[i][k], SredaDoSati[i][k], SredaDoMinuta[i][k], SredaPredavac[i][k], SredaPredmeti[i][k], SredaKabinet[i][k]);
				}
	}
	
	public static void nadjiDan(String Dani[],int j, int i){
		if(Dani[j] == "Ponedeljak")
			ispisiPonedeljak(i);
		else if(Dani[j] == "Utorak")
			ispisiUtorak(i);
		else
			ispisiSredu(i);
	}
	
	public static void main(String[] args){
		String Godina[] = {"I Godina", "III Godina", "IV Godina"};
		String Dani[] = {"Ponedeljak", "Utorak", "Sreda"};
		String Termin[] = {"odSati", "doSati", "Predavac", "Predmet", "Kabinet"};
		
		
		
		
		
		
		
		for(int i = 0; i < Godina.length; i++){
			System.out.printf("%30s \n\n", Godina[i]);
			for(int j = 0; j < Dani.length; j++){
				System.out.printf("%31s \n", Dani[j]);
				for(int k = 0; k < Termin.length; k++){
					if(Termin[k] == "Predavac")
						System.out.printf("%-17s ", Termin[k]);
					else if(Termin[k] == "Predmet")
						System.out.printf("%-30s ", Termin[k]);
					else
					System.out.printf("%s ", Termin[k]);
			}
				System.out.println();
				
				nadjiDan(Dani, j, i);
				
				System.out.println();
		}
		
		}
		/*String tempIme[] = new String[10];
		for(int i = 0; i < PonedeljakPredavac.length; i++){
			int temp = 0;
			for(int j = 0; j < PonedeljakPredavac[i].length-1; j++){
				for(int k = 1; k < PonedeljakPredavac[i].length; k++)
					if(PonedeljakPredavac[i][j] == PonedeljakPredavac[i][k]){
						tempIme[temp] = PonedeljakPredavac[i][j];
						temp++;
					}
			}
			System.out.println(tempIme[i]+ " se ponavlja " +temp+ " puta.");
		}*/
	
	}
	
}
